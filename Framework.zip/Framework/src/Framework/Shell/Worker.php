<?php

namespace Framework\Shell;

/**
 * Class Worker.
 *
 * @category PHP
 */
class Worker
{
    public function __construct()
    {
        
    }
}

// end of script
