<?php

namespace Framework\Resource;

use Framework\Base\ResourceInterface;

/**
 * Class Resource.
 *
 * @category PHP
 */
class Resource implements ResourceInterface
{
    public function __construct()
    {

    }

    public function preRun()
    {

    }

    public function afterRun()
    {

    }
}

// end of script
