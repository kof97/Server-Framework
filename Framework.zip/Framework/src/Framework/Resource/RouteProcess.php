<?php

namespace Framework\Resource;

/**
 * Class RouteProcess.
 *
 * @category PHP
 */
class RouteProcess
{
    private function __construct()
    {
        // It should never be used.
    }

    public static function processRoute()
    {
        
    }
}

// end of script
