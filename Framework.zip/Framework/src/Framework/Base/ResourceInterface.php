<?php

namespace Framework\Base;

/**
 * interface ResourceInterface.
 *
 * @category PHP
 */
interface ResourceInterface
{
    public function preRun();

    public function afterRun();
}

// end of script
