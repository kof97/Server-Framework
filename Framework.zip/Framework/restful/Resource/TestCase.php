<?php

namespace Resource;

use Framework\Resource\Resource;
use Model;

/**
 * 
 */
class TestCase extends Resource
{
    public function run()
    {
    	$model = new Model\Test();
    }
}




// end of script
